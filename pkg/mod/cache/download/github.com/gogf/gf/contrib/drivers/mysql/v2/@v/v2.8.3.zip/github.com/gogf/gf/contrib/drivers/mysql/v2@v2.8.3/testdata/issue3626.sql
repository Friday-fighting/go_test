CREATE TABLE `issue3626` (
    id        int(11) NOT NULL,
    name      varchar(45) DEFAULT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;