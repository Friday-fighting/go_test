CREATE TABLE "public"."%s" (
  "one" int8[] NOT NULL,
  "two" text[][] NOT NULL
);
