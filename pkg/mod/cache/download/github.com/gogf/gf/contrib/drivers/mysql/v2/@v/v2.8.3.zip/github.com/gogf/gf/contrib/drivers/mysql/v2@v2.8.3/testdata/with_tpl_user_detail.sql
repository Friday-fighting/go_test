CREATE TABLE IF NOT EXISTS %s (
    uid int(10) unsigned NOT NULL AUTO_INCREMENT,
    address varchar(45) NOT NULL,
    PRIMARY KEY (uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;