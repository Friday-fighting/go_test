CREATE TABLE "public"."%s" (
  "text" varchar(255) COLLATE "pg_catalog"."default",
  "number" int4
);
