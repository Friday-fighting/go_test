package sub

type SubBase struct {
}

// subbase init
func (*SubBase) Init() {

}

// subbase  GetSubBase
func (*SubBase) GetSubBase() {

}
