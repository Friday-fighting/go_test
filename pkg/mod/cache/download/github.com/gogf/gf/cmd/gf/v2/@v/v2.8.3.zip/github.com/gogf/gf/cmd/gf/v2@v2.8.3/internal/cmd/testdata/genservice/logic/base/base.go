package base

type Base = sBase

type sBase struct {
	baseDestory `gen:"extend"`
}

// sBase Init
func (*sBase) Init() {

}

// sBase Destory
func (*sBase) Destory() {

}
