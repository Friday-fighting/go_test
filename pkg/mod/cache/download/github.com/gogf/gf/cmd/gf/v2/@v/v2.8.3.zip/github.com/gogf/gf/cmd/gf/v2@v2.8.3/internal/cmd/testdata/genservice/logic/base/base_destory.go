package base

type baseDestory struct{}

// baseDestory Destory
func (baseDestory) Destory() {

}

// baseDestory BeforeDestory
func (baseDestory) BeforeDestory() {

}
