package TestIssues

import "testing"

func TestIssue356(t *testing.T) {

}
