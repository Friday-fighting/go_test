package proto

//go:generate go run ./cmd/ch-gen-col
