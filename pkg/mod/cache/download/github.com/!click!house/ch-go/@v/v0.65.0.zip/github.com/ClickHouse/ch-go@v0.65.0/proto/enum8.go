package proto

// Enum8 represents raw Enum8 value.
//
// Actual values should be taken from DDL.
type Enum8 int8
