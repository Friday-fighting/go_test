# Internal Documentation

* [Architecture of Delve slides](https://speakerdeck.com/aarzilli/internal-architecture-of-delve).
* [Notes on porting Delve to other architectures](portnotes.md)

TODO(derekparker)

This directory will hold documentation around the internals of the debugger and how it works.
